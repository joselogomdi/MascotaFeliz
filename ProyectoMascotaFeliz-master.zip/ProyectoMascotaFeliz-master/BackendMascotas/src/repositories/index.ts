export * from './mascota.repository';
export * from './plan.repository';
export * from './producto-servicio.repository';
export * from './prospecto.repository';
export * from './sucursal.repository';
export * from './usuario.repository';
