export namespace Llaves{
  export const claveJWT = 'Juan123+';
  export const urlServicioNotificaciones = 'http://localhost:5000';
}
